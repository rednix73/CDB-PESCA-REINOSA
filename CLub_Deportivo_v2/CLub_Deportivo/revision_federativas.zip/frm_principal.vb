﻿Public Class frm_principal

    Private Sub SociosToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SociosToolStripMenuItem.Click

    End Sub

    Private Sub frm_principal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            bbdd.leer_configuracion()
            bbdd.cargar()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click

        ' Cierre ordenado: FormClosing hace la purga (una sola vez).
        ' "End" terminaba el proceso de golpe, sin eventos de cierre.
        Me.Close()

    End Sub

    Private Sub frm_principal_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        ' Llamar a la purga también cuando se cierra la ventana principal (X, Alt+F4, etc.)
        Try
            bbdd.PurgeDeletedFederativas()
        Catch
        End Try
    End Sub

    Private Sub ListadosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListadosToolStripMenuItem.Click
        frm_listados.Show()

    End Sub

    Private Sub AcercaDeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AcercaDeToolStripMenuItem.Click
        Acerca_de.Show()

    End Sub

    Private Sub GuardarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GuardarToolStripMenuItem.Click
        Try

            If (Not ds_club.GetChanges Is Nothing) Then
                conectar()
                Select Case bbdd.tp
                    Case tipobd.Excel_ODBC
                        da_socios2.Update(ds_club.Tables(0))
                        da_bdsocios2.Update(ds_club.Tables(1))
                        da_federa2.Update(ds_club.Tables(2))

                    Case tipobd.MySQL
                        da_socios1.Update(ds_club.Tables(0))
                        da_bdsocios1.Update(ds_club.Tables(1))
                    Case Else
                End Select

                desconectar()
                ds_club.AcceptChanges()
                ' Después de guardar, ofrecer purga física si hay eliminaciones lógicas
                Try
                    bbdd.PurgeDeletedFederativas()
                Catch
                End Try
                bbdd.cargar()
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub NuevoSocioToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NuevoSocioToolStripMenuItem.Click
        frm_socio.MdiParent = Me
        frm_socio.Show()
        frm_socio.btn_buscar_nsocio.Visible = True
        frm_socio.btn_buscar_dni.Visible = True
        frm_socio.btn_buscar_apell.Visible = True
        frm_socio.btn_eliminar.Visible = False
        frm_socio.btn_modificar.Visible = False

    End Sub

    Private Sub ModificarSocioToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ModificarSocioToolStripMenuItem.Click
        frm_socio.MdiParent = Me
        frm_socio.Show()
        frm_socio.btn_buscar_nsocio.Visible = True
        frm_socio.btn_buscar_dni.Visible = True
        frm_socio.btn_buscar_apell.Visible = True
        frm_socio.btn_eliminar.Visible = False
        frm_socio.btn_modificar.Visible = True
        frm_socio.btn_insertar.Visible = False
    End Sub

    Private Sub EliminarSocioToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EliminarSocioToolStripMenuItem.Click
        frm_socio.MdiParent = Me
        frm_socio.Show()
        frm_socio.btn_buscar_nsocio.Visible = True
        frm_socio.btn_buscar_dni.Visible = True
        frm_socio.btn_buscar_apell.Visible = True
        frm_socio.btn_eliminar.Visible = True
        frm_socio.btn_modificar.Visible = False
        frm_socio.btn_insertar.Visible = False
    End Sub

    Private Sub ConfiguraciónToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConfiguraciónToolStripMenuItem.Click
        frm_configuracion.Show()
    End Sub

    Private Sub ActuaizarBBDDToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ActuaizarBBDDToolStripMenuItem.Click
        frm_actualizar_bbdd.ShowDialog()
    End Sub

    Private Sub NuevaTarjetaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NuevaTarjetaToolStripMenuItem.Click
        frm_federativas.MdiParent = Me
        frm_federativas.Show()
        frm_federativas.btn_buscar_nsocio.Visible = True
        frm_federativas.btn_buscar_dni.Visible = True
        frm_federativas.btn_buscar_apell.Visible = True
        frm_federativas.btn_eliminar.Visible = False
        frm_federativas.btn_modificar.Visible = False
    End Sub

    Private Sub ModificarTarjetaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ModificarTarjetaToolStripMenuItem.Click
        frm_federativas.MdiParent = Me
        frm_federativas.Show()
        frm_federativas.btn_buscar_nsocio.Visible = True
        frm_federativas.btn_buscar_dni.Visible = True
        frm_federativas.btn_buscar_apell.Visible = True
        frm_federativas.btn_eliminar.Visible = False
        frm_federativas.btn_modificar.Visible = True
        frm_federativas.btn_insertar.Visible = False
    End Sub

    Private Sub EliminarTarjetaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EliminarTarjetaToolStripMenuItem.Click
        frm_federativas.MdiParent = Me
        frm_federativas.Show()
        frm_federativas.btn_buscar_nsocio.Visible = True
        frm_federativas.btn_buscar_dni.Visible = True
        frm_federativas.btn_buscar_apell.Visible = True
        frm_federativas.btn_eliminar.Visible = True
        frm_federativas.btn_modificar.Visible = False
        frm_federativas.btn_insertar.Visible = False
    End Sub
End Class